---
name: prompt-learning-assistant
description: Systematic learning of 58+ AI prompt engineering techniques with real-world cases, personalized learning paths, and quick reference. Perfect for AI beginners to experts who want to master prompt engineering through structured lessons, practical examples, and progressive difficulty levels from beginner to advanced.
---

# Prompt Learning Assistant - 提示词工程学习助手

> 系统化学习 58+ 种 AI 提示词技术，包含实战案例和学习路径

## 简介

这是一个帮助用户系统化学习 AI 提示词工程的技能。包含 58+ 种提示词技术详解、20+ 真实案例分析，以及个性化的学习路径推荐。无论你是 AI 初学者还是想进阶的用户，都能在这里找到适合的学习内容。

## 核心功能

### 📚 知识库检索
- 58+ 种提示词技术详解
- 按难度分类：入门/进阶/专家
- 按场景分类：编程/创作/分析/对话
- 自然语言搜索，快速找到需要的内容

### 💡 实战案例分析
- 20+ 真实案例对比
- 优化前后效果展示
- 标注使用的技术组合
- 可直接复制到剪贴板使用

### 🗺️ 学习路径推荐
- 根据用户目标推荐学习顺序
- 分步教程，循序渐进
- 包含进度追踪（计划中）

### ⚡ 快速速查
- 一句话解释技术要点
- 适用场景说明
- 适合已学技术的快速复习

## 使用方法

### 基础命令

**开始学习**
```
学习 提示词工程
prompt learn
```
显示学习系统概览，引导进入系统化学习

**查看案例**
```
案例 写作
example 创意写作
```
查看特定场景的实战案例

**获取学习路径**
```
路径 提高效率
path 优化工作流
```
根据目标获取个性化的学习路径

**快速速查**
```
速查 Few-shot
quick chain-of-thought
```
快速查询技术的要点和使用场景

### 进阶用法

**按难度查询**
```
学习 入门级
prompt beginner techniques
```
**按场景查询**
```
案例 编程
example data analysis
```

## 技术分类

### 入门级（必学）
- 角色扮演（Role-playing）
- 逐步思考（Chain-of-Thought）
- 示例驱动（Few-shot）
- 结构化输出（Structured Output）
- 系统指令（System Prompt）
- 任务分解（Task Decomposition）
- 输出格式化（Output Formatting）
- 约束条件（Constraints）

### 进阶级
- 思维树（Tree-of-Thought）
- 自我反思（Self-Reflection）
- 对比分析（Comparison）
- 多角色辩论（Multi-Role Debate）
- 思维链优化（CoT Refinement）
- 知识蒸馏（Knowledge Distillation）
- 风格迁移（Style Transfer）
- 跨领域应用（Cross-Domain）

### 专家级
- ReAct 推理
- Prompt Chaining
- 思维图谱（Mind Map）
- 元提示（Meta-Prompting）
- 自适应提示（Adaptive Prompting）
- 递归思考（Recursive Thinking）
- 集成学习（Ensemble Learning）
- 代理协作（Agent Collaboration）

## 适用人群

- ✅ **AI 初学者**：从零开始系统学习
- ✅ **内容创作者**：提高写作效率和质量
- ✅ **开发者**：优化代码生成和调试
- ✅ **数据分析师**：提升数据分析准确性
- ✅ **营销人员**：优化文案和策略
- ✅ **任何想用好 AI 的人**：让 AI 成为你的得力助手

## 技术特点

- 🎯 **系统性**：不是零散的技巧，而是完整的学习体系
- 💎 **实战导向**：每个技术都有真实案例支撑
- 📖 **循序渐进**：从入门到专家，分难度推进
- ⚡ **即学即用**：案例可直接复制使用
- 🔧 **Clawdbot 集成**：无缝集成到你的工作流

## 定价

**订阅制**：
- 💰 $19/月 - 完整访问权限
- 💎 $49/季 - 季度优惠（省 $8）
- ⭐ $179/年 - 年度特惠（省 $49）

**免费内容**：
- 入门级 4 种技术
- 5 个精选案例
- 学习路径概览

**付费内容解锁**：
- 全部 58+ 种技术
- 20+ 实战案例
- 个性化学习路径
- 快速速查功能
- 持续更新的新内容

## 更新计划

### V1.1（即将推出）
- 📊 进度追踪功能
- 🤝 用户贡献案例
- 🌍 多语言支持（英文）

### V1.2（规划中）
- 🤖 AI 评估功能：分析你的提示词
- 💡 提示词优化建议
- 👥 社区互动功能

## 为什么选择这个技能？

市面上有很多免费的提示词教程，但它们存在以下问题：

❌ **零散不成体系**：技巧分散，不知道先学哪个
❌ **理论脱离实际**：讲了理论，不知道怎么用
❌ **缺少持续更新**：一次发布，不再更新
❌ **没有个性化**：一刀切，不符合你的需求

**我们的优势**：
✅ **系统化学习路径**：从入门到专家，分难度推进
✅ **实战案例驱动**：每个技术都有真实案例
✅ **持续内容更新**：定期添加新技术和新案例
✅ **个性化推荐**：根据你的目标定制学习路径
✅ **Clawdbot 原生集成**：无缝融入你的工作流

## 常见问题

**Q: 我完全不懂 AI，能学吗？**
A: 完全可以！我们有入门级内容，从最基础开始，循序渐进。

**Q: 学完能做什么？**
A: 学完后，你能熟练编写高质量的提示词，让 AI 帮你完成写作、编程、分析等各种任务，极大提升工作效率。

**Q: 内容多久更新一次？**
A: 我们每月都会添加新技术和新案例，确保内容始终最新。

**Q: 可以退款吗？**
A: 购买后 7 天内，如果不满意，可以申请全额退款。

**Q: 需要什么基础吗？**
A: 不需要任何技术背景，只需要有使用 ChatGPT 或类似 AI 的基本经验即可。

## 作者

jack happy - AI 提示词工程爱好者，致力于让每个人都能用好 AI

## 支持

如有问题或建议，请联系作者或在社区反馈。

---

**让 AI 成为你最强大的工具，从掌握提示词开始！** 🚀
